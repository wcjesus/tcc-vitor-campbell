# Guia Rápido — Como usar o template LaTeX (TCC / Projeto)

## 1. Onde escrever seu trabalho

NÃO escreva no arquivo `principal.tex`.

Escreva seus textos na pasta:

2-capitulos/

Exemplo:
- introducao.tex
- desenvolvimento.tex
- consideracoes-finais.tex

Esses arquivos já estão sendo chamados automaticamente.

---

## 2. Como preencher seus dados

Abra o arquivo:

1-pre-textuais/dados-do-trabalho.tex

Preencha:
- título
- nome
- orientador
- coorientador (se houver)
- ano
- tipo de trabalho

---

## 3. Resumo

Edite:

1-pre-textuais/resumo.tex  
1-pre-textuais/abstract.tex

- resumo → obrigatório  
- abstract → recomendado  

---

## 4. Referências

Use o arquivo:

referencias.bib

- siga os modelos já existentes
- cite no texto usando \cite{...}

---

## 5. Figuras e tabelas

- Insira diretamente nos capítulos
- As listas são automáticas
- Só ative lista de figuras/tabelas se realmente usar muitas

---

## 6. Elementos opcionais

Você pode usar (ou não):
- dedicatória
- agradecimentos
- epígrafe
- listas de siglas e símbolos

Se não usar, deixe comentado no `principal.tex`.

---

## 7. Folha de aprovação e ficha catalográfica

- Use a versão provisória durante a escrita
- Após a defesa, substitua pelo PDF assinado

---

## 8. Compilar

Sempre compile o arquivo:

principal.tex

---

## 9. Dica importante

Não altere o `preambulo.tex` sem necessidade.

---

## 10. Em caso de erro

Verifique:
- nomes dos arquivos
- caminhos das pastas
- se o arquivo está sendo incluído corretamente
